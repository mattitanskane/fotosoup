# How to use
```
pipenv run python main.py
```
or
```
pipenv shell
python main.py
```
# Credits
![Image of a bird for testing purposes](https://github.com/mattitanskane/fotosoup/blob/main/test.jpg)

Test photo by <a href="https://unsplash.com/@aarngiri?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText">AARN GIRI</a> on <a href="https://unsplash.com/s/photos/bird?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText">Unsplash</a>